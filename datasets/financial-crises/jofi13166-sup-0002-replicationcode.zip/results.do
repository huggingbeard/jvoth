cd "YOUR PATH HERE"

set more off
set gr off

////////////////////////////////////////////
////////////////////////////////////////////
// Figures
////////////////////////////////////////////
////////////////////////////////////////////

/////////////////////////////
// Figure 1. Danatbank and the Crisis in Newspapers.
import delimited "input_files/newspapers.csv", encoding(ISO-8859-1)clear
gen date2 = monthly(date,"YM")
format date2 %tm

line std_dankrise_occurences std_drekrise_occurences std_deu_occurences date2, xline(-343, lcol(gs9) lpat(-)) ///
	lcol(ebblue cranberry black) lpat(solid - -.) ///
	legend(region(lcol(white)) title("occurences of" "Krise and", color(black)) order(1 "Danat" 2 "Dresdner" 3 "Deutsche") row(3) pos(11) ring(0)) ///
	ytitle("occurences (1930m7= 1)", size(medlarge)) xtitle("") ///
	graphregion(color(white)) bgcolor(white) ylabel(,nogrid)
gr export "output_files/Fig1a.eps", replace

line std_goldschmidt_occurences std_nathan_occurences std_goetz_occurences std_wasserman_occurences date2, xline(-343, lcol(gs9) lpat(-)) ///
	lcol(ebblue cranberry cranberry black)  lpat(solid - _ -.) ///
	legend(region(lcol(white)) title("occurences of", color(black)) pos(11) order(1 "Goldschmidt" 2 "Nathan" 3 "Goetz" 4 "Wassermann") row(4) ring(0)) ///
	ytitle("occurences (1930m7= 1)", size(medlarge)) xtitle("") ///
	graphregion(color(white)) bgcolor(white) ylabel(,nogrid)
gr export "output_files/Fig1b.eps", replace

/////////////////////////////
// Figure 2. The Banking Crisis and Nazi Voting: 1930–1932/7
import delimited "input_files/master_c.csv", encoding(ISO-8859-1)clear

tw (kdensity n327 if branchexp==0, bw(0.025) clcol(ebblue) clpat(-)) ///
	(kdensity n327 if branchexp==1, bw(0.025) clcol(black) clpat(solid) ///
	graphregion(color(white)) bgcolor(white) ylabel(,nogrid) ///
	title("") note("") ytitle("density", size(medlarge)) xtitle("{&Delta}NSDAP votes September 1930 - July 1932", size(medsmall)) ///
	legend(ring(0) rows(1) pos(7) order(1 "no Danat branch/exposure" 2 "Danat branch/exposure" ) region(col(white))) )
gr export "output_files/Fig2.eps", replace

/////////////////////////////
// Figure 3. Danatbank – Geographic Distribution
import delimited "input_files/master_c.csv", encoding(ISO-8859-1)clear

label define danat 0 "no Danat" 1 "Danat"
label values branchexp danat
keep  city_l* branchexp
gen _ID=_n
save "spmap_temp.dta", replace
spmap using "input_files/spmap_reich_coord.dta", id(_ID) ///
	point(data("`tmap'") by(branchexp) x(city_lon) ///
	y(city_lat) ocolor(gs7 ebblue) fcolor(none ebblue)  ///
	legenda(on) shape(d o) size(medium large) osize(medthick)) legend(pos(5) row(2) size(*2.5))
gr export "output_files/Fig3.eps", replace
cap erase "spmap_temp.dta"

/////////////////////////////
// Figure 4. Firm Pre-Crisis Leverage and Size
import delimited "input_files/firm_graphs.csv", encoding(ISO-8859-1)clear

tw (kdensity lev if zahlstelleother == 1, ///
	clpat(dash) clc(gs3) bw(0.5))  ///
	(kdensity lev if danat == 1, ///
	clpat(solid) clc(ebblue) bw(0.5) lw(medthick)) ///
	(kdensity lev if zahlstellegrossbank == 1, ///
	clpat(-.) clc(cranberry) bw(0.5) lw(medthick) ///
	 note("") ytitle("density", size(large)) xtitle("firm leverage 1929", size(large)) ///
	legend(rows(3) label(1 "Other connected") label(2 "Danat connected") label(3 "Grossbank connected") ring(0) pos(2) size(large)) ///
	graphregion(color(white)) bgcolor(white) ytitle("density")  scheme(lean2) ylabel(,nogrid))
gr export "output_files/Fig4a.eps", replace

tw (kdensity lass_wage, clcol(ebblue) bw(0.5)) ///
	(kdensity lass_all, clcol(black) clpat(-.) bw(0.5) ///
	title("") note("") ytitle("density", size(large)) xtitle("log(firm assets 1929)", size(large)) ///
	legend(rows(2) label(1 "wage sample (n = 386)") label(2 "universe of joint stock companies (n = 5,610)") ring(0) pos(10) size(medlarge)) ///
	graphregion(color(white)) bgcolor(white)  scheme(lean2)  ylabel(,nogrid) ///
	yscale(range(0 0.35)))
gr export "output_files/Fig4b.eps", replace

/////////////////////////////
// Figure 5. Pre-trends.
import delimited "input_files/master_c.csv", encoding(ISO-8859-1)clear
foreach var in elec285 elec309 elec327 elec3211 elec333 {
qui: reg `var' branchexp lpop25 bcollar jewish prot, r a(wahlkreis)
qui gen b_`var' = _b[branchexp]
qui gen lb_`var' = _b[branchexp] - invttail(e(df_r),0.05)*_se[branchexp]
qui gen ub_`var' = _b[branchexp] + invttail(e(df_r),0.05)*_se[branchexp]
}

keep b_* lb_* ub_*
gen id = 1
keep in 1
reshape long b_ lb_ ub_, i(id) j(election) string
replace id = _n

tw  (bar b id, barwidth(0.75) color(ebblue)) ///
	(rcap lb ub id, lcol(black)) ///
	(rcap lb ub id, lcol(black) ///
	xtitle("election dates") ///
	xlabel(1 "5/24 - 9/30" 2 "5/28 - 9/30" 3 "9/30 - 7/32" 4 "9/30 - 11/32" 5 "9/30 - 3/33", labsize(small)) ///
	ytitle("coefficient estimate") ylabel(,nogrid) yline(0, lwidth(thin) lcol(black)) ///
	graphregion(color(white)) bgcolor(white) ///
	legend(off) )
gr export "output_files/Fig5a.eps", replace


import delimited "input_files/master_ct.csv", encoding(ISO-8859-1)clear
reghdfe ns ddate1 ddate2 ddate4 ddate5 ddate6 lpop25 bcollar25 jewish prot,  a(town wid#date) cl(town)
tempfile t1
regsave ddate1 ddate2 ddate4 ddate5 ddate6 using "`t1'", ci level(90) replace
use "`t1'", clear
gen t = real(substr(var,6,1))
replace t = t-1 if t>3
sort t
replace coef = 0 if coef == .
replace ci_u = 0 if coef == .
replace ci_l = 0 if coef == .

tw  (bar coef t, barwidth(0.75) color(ebblue)) ///
	(rcap ci_l ci_u t, lcol(black) ///
	xtitle("election dates") ///
	xlabel(1 "5/24" 2 "5/28" 3 "7/32" 4 "11/32" 5 "3/33", labsize(small)) ///
	ytitle("coefficient estimate") ylabel(,nogrid) yline(0, lwidth(thin) lcol(black)) ///
	graphregion(color(white)) bgcolor(white) ///
	legend(off) )
gr export "output_files/Fig5b.eps", replace

////////////////////////////////////////////
////////////////////////////////////////////
// Tables
////////////////////////////////////////////
////////////////////////////////////////////

import delimited "input_files/master_c.csv", encoding(ISO-8859-1)clear

/////////////////////////////
// Table I: Descriptive statistics
qui: estpost su branchexp exposure_dan_asset danat_hasbranch1930 branchexp_dre chnsdap327 chnsdap3211 chnsdap333 pca_persecution dinc2834 dinc2834hat c25pop bcollar jewish prot ase pog,d
esttab using "output_files/Tab1", cells("count mean sd p25 p50 p75") csv replace nomtitle nonumber noobs

/////////////////////////////
// Table II: Balancedness
preserve
center lpop25 bcollar jewish prot lincpc urate1930, inplace standardize nolabel
est clear
qui{
eststo: reg branchexp lpop25 bcollar jewish prot lincpc urate1930, r
eststo: reg branchexp lpop25 bcollar jewish prot lincpc urate1930, a(wahlkreis) r
eststo: reg danat_hasbranch1930 lpop25 bcollar jewish prot lincpc urate1930, r
eststo: reg danat_hasbranch1930 lpop25 bcollar jewish prot lincpc urate1930, a(wahlkreis) r
eststo: reg exposure_dan_asset lpop25 bcollar jewish prot lincpc urate1930, r
eststo: reg exposure_dan_asset lpop25 bcollar jewish prot lincpc urate1930, a(wahlkreis) r
}
esttab using "output_files/Tab2", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv
restore

/////////////////////////////
// Table III: Danat and Nazi voting

* Panel A
est clear
qui{
eststo: reg chnsdap327 branchexp lpop25, r 
eststo: reg chnsdap327 branchexp lpop25 bcollar jewish prot, r 
eststo: reg chnsdap327 branchexp lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap3211 branchexp lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap333 branchexp lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsmean branchexp lpop25 bcollar jewish prot, r a(wahlkreis)
}
esttab using "output_files/Tab3a", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv

* Panel B
est clear
qui{
eststo: reg chnsdap327 exposure_dan_asset lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap3211 exposure_dan_asset lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap333 exposure_dan_asset lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap327 danat_hasbranch1930 lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap3211 danat_hasbranch1930 lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap333 danat_hasbranch1930 lpop25 bcollar jewish prot, r a(wahlkreis)
}
esttab using "output_files/Tab3b", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv

/////////////////////////////
// Table IV: The Economic Channel

* Panel A
est clear
qui{
eststo: reg dinc2834 branchexp lpop25 bcollar jewish prot, r
eststo: reg dinc2834 branchexp lpop25 bcollar jewish prot, r  a(wahlkreis)
eststo: reg chnsdap327 dinc2834 lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap3211 dinc2834 lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap333 dinc2834 lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsmean dinc2834 lpop25 bcollar jewish prot, r a(wahlkreis)
}
esttab using "output_files/Tab4a", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv

* Panel B
est clear
qui{
eststo: reg chnsdap327 dinc2834hat lpop25 bcollar jewish prot, vce(r) a(wahlkreis)
eststo: reg chnsdap327 dinc2834hat dinc2834 lpop25 bcollar jewish prot, vce(r) a(wahlkreis)
eststo: reg chnsdap327_tilde branchexp dinc2834 lpop25 bcollar jewish prot, vce(r) a(wahlkreis)
eststo: reg chnsdap3211_tilde branchexp dinc2834 lpop25 bcollar jewish prot, vce(r) a(wahlkreis)
eststo: reg chnsdap333_tilde branchexp dinc2834 lpop25 bcollar jewish prot, vce(r) a(wahlkreis)
}
esttab using "output_files/Tab4b", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv
sgmediation chnsdap327, mv(dinc2834) iv(branchexp) cv(lpop25 bcollar jewish prot wfe1 wfe2 wfe3 wfe4 wfe5 wfe6 wfe7 wfe8 wfe9 wfe10 wfe11 wfe12 wfe13 wfe14)

/////////////////////////////
// Table V: The Cultural Channel: historical anti-Semitism
est clear
qui{
eststo: reg chnsdap327 branchexp  lpop25 bcollar jewish prot, r, if ase==0
eststo: reg chnsdap327 branchexp  lpop25 bcollar jewish prot, r, if ase==1
preserve
import delimited "input_files/master_ct.csv", encoding(ISO-8859-1)clear
eststo: reghdfe dns branchexppost branchexppostase lpop25ase bcollar25ase jewishase protase, a(town wid#date) cl(town)
restore
eststo: reg chnsdap327 branchexp  lpop25 bcollar jewish prot, r, if pog==0
eststo: reg chnsdap327 branchexp  lpop25 bcollar jewish prot, r, if pog==1
preserve
import delimited "input_files/master_ct.csv", encoding(ISO-8859-1)clear
eststo: reghdfe dns branchexppost branchexppostpog lpop25pog bcollar25pog jewishpog protpog, a(town wid#date) cl(town)
restore
}
esttab using "output_files/Tab5", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv


/////////////////////////////
// Table VI: The Cultural Channel: Danat vs Dresdner
est clear
qui{
eststo: reg dinc2834 branchexp_dre lpop25 bcollar jewish prot, r
eststo: reg dinc2834 branchexp_dre branchexp lpop25 bcollar jewish prot, r
eststo: reg chnsdap327  branchexp_dre lpop25 bcollar jewish prot, r
eststo: reg chnsdap327 branchexp branchexp_dre lpop25 bcollar jewish prot, r
eststo: reg chnsdap327 branchexp branchexp_dre lpop25 bcollar jewish prot, r, if ase==0
eststo: reg chnsdap327 branchexp branchexp_dre lpop25 bcollar jewish prot, r, if ase==1
eststo: reg chnsdap327 branchexp branchexp_dre lpop25 bcollar jewish prot, r, if pog==0
eststo: reg chnsdap327 branchexp branchexp_dre lpop25 bcollar jewish prot, r, if pog==1
}
esttab using "output_files/Tab6", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv

/////////////////////////////
// Table VII: Persecution After 1933
est clear
qui{
eststo: reg pca_persecution branchexp lpop25 bcollar jewish prot, r 
eststo: reg pca_persecution exposure_dan_asset lpop25 bcollar jewish prot, r 
eststo: reg pca_persecution danat_hasbranch1930 lpop25 bcollar jewish prot, r 
eststo: reg pca_persecution branchexp lpop25 bcollar jewish prot, r a(wahlkreis) 
eststo: reg pca_persecution exposure_dan_asset lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg pca_persecution danat_hasbranch1930 lpop25 bcollar jewish prot, r a(wahlkreis)
}
esttab using "output_files/Tab7", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv

/////////////////////////////
// Table VIII: The Economic Channel: Firm-Level Evidence
import delimited "input_files/master_f.csv", encoding(ISO-8859-1)clear
est clear
qui{
eststo: reghdfe grwages danat, cluster(cityid) noabsorb
eststo: reghdfe grwages danat age lassets29 roa29 leverage29 , cluster(cityid) noabsorb
eststo: reghdfe grwages danat age lassets29 roa29 leverage29, cluster(cityid) a(indid)
eststo: reghdfe grwages danat age lassets29 roa29 leverage29, cluster(cityid) a(indid), if fesample==1
eststo: reghdfe grwages danat age lassets29 roa29 leverage29, cluster(cityid) a(cityid indid), if fesample==1
eststo: reghdfe grwages danat dresdner age lassets29 roa29 leverage29, cluster(cityid) a(indid)
eststo: reghdfe grwages danat1923 danatnew age lassets29 roa29 leverage29, cluster(cityid) a(indid)
}
esttab using "output_files/Tab8", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv

/////////////////////////////
// Table IX: Anti-Finance Sentiment
import delimited "input_files/master_c.csv", encoding(ISO-8859-1)clear
est clear
qui{
eststo: reg chnsdap327 c_n285pcvrp lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap327 branchexp c_n285pcvrp lpop25 bcollar jewish prot, r a(wahlkreis)
eststo: reg chnsdap327 branchexp c_jewish danjew c_share_jfin danjewfin c_share_allfin danfin lpop25 bcollar  prot, r a(wahlkreis)
eststo: reg chnsdap327 branchexp c_jewish danjew c_share_jfin danjewfin c_share_allfin danfin lpop25 bcollar  prot, r , if ase==0
eststo: reg chnsdap327 branchexp c_jewish danjew c_share_jfin danjewfin c_share_allfin danfin lpop25 bcollar  prot, r , if ase==1
eststo: reg chnsdap327 branchexp c_jewish danjew c_share_jfin danjewfin c_share_allfin danfin lpop25 bcollar  prot, r , if pog==0
eststo: reg chnsdap327 branchexp c_jewish danjew c_share_jfin danjewfin c_share_allfin danfin lpop25 bcollar  prot, r , if pog==1
}
esttab using "output_files/Tab9", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv


/////////////////////////////
// Table X: Other Economic Outcomes
preserve
keep if uratesample==1
est clear
qui{
eststo: reg dur30 branchexp lpop25 bcollar jewish prot, r  a(wahlkreis)
eststo: reg dur31 branchexp lpop25 bcollar jewish prot, r  a(wahlkreis)
eststo: reg urate1930 branchexp lpop25 bcollar jewish prot, r  a(wahlkreis)
eststo: reg chnsdap327 branchexp dur30 dandur30 lpop25 bcollar jewish prot, r a(wahl)
eststo: reg chnsdap327 branchexp dur31 dandur31 lpop25 bcollar jewish prot, r a(wahl)
eststo: reg dur32 branchexp lpop25 bcollar jewish prot, r a(wahl)
}
esttab using "output_files/Tab10", star(* .1 ** .05 *** .01) r2 replace label b(%9.3f) se(%9.3f) r2(%9.3f)  csv
restore

