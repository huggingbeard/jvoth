--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------
Readme to data and code
--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------

Doerr, Sebastian, Stefan Gissler, Jose-Luis Peydro and Hans-Joachim Voth: �Financial crises and political radicalization: How failing banks paved Hitler�s path to power,� Journal of Finance.

--------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------------------------------------

The file �results.do� produces the figures and tables in the paper and saves them in the folder �output_files�.

To do so, it uses the following files in the folder "input_files":
1. �newspapers.csv�: time series data on newspaper mentioned of banks and CEOs
2. �master_c.csv�: cross-sectional dataset with city-level variables
3. �master_ct.csv�: panel dataset with city-year-level variables
4. �firm_f.scv�: cross-sectional dataset with firm-level variables
5. �firm_graphs.csv�: firm-level dataset with information on firm assets and leverage
6. �spmap_reich_coord.dta�: shape file required to create a map fo 1930s Germany

Note that all variables that are based on data from the �Handbook deutscher Aktiengesellschaften� are randomized to maintain confidentiality. These include
- exposure_dan_asset, danat_hasbranch1930, branchexp, branchexp_dre, danjew, danjewfin, danfin, dandur30, and dandur31 in file �master_c.csv�
- branchexppost, branchexppostase, branchexppostpog, ddate1, ddate2, ddate4, ddate5, and ddate6 in file �master_ct.csv�
- lev, zahlstelledanat, zahlstellegrossbank, danat, zahlstelleother, lass_all, and lass_wage in file �firm_graphs.csv�
- grwages, danat, dresdner, danat1923, danatnew, age, lassets29, roa29, and leverage29 in file �master_f.csv� 
